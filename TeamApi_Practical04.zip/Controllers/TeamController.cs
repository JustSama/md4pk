using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using TeamApi_Practical04.DTOs;
using TeamApi_Practical04.Models;
using TeamApi_Practical04.Repositories;

namespace TeamApi_Practical04.Controllers;

[ApiController]
[Route("api/team")]
public class TeamController : ControllerBase
{
    private readonly ITeamRepository _repository;
    private readonly IMapper _mapper;

    public TeamController(
        ITeamRepository repository,
        IMapper mapper)
    {
        _repository = repository;
        _mapper = mapper;
    }

    [HttpGet]
    public async Task<ActionResult<ReturnResult<IEnumerable<TeamDto>>>> GetAll()
    {
        var teams = await _repository.GetAllAsync();
        var result = _mapper.Map<IEnumerable<TeamDto>>(teams);

        return Ok(ReturnResult<IEnumerable<TeamDto>>.Ok(
            result,
            "Teams retrieved successfully."));
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<ReturnResult<TeamDto>>> Get(int id)
    {
        var team = await _repository.GetAsync(id);

        if (team == null)
        {
            return NotFound(ReturnResult<TeamDto>.Fail(
                $"Team with id {id} was not found."));
        }

        var result = _mapper.Map<TeamDto>(team);

        return Ok(ReturnResult<TeamDto>.Ok(
            result,
            "Team retrieved successfully."));
    }

    [HttpPost]
    public async Task<ActionResult<ReturnResult<TeamDto>>> Create(
        [FromBody] TeamDto dto)
    {
        var team = _mapper.Map<Team>(dto);

        team.Id = 0;
        team.Description = null;

        await _repository.CreateAsync(team);

        var result = _mapper.Map<TeamDto>(team);

        return CreatedAtAction(
            nameof(Get),
            new { id = result.Id },
            ReturnResult<TeamDto>.Ok(
                result,
                "Team created successfully."));
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<ReturnResult<TeamDto>>> Update(
        int id,
        [FromBody] TeamDto dto)
    {
        var existingTeam = await _repository.GetAsync(id);

        if (existingTeam == null)
        {
            return NotFound(ReturnResult<TeamDto>.Fail(
                $"Team with id {id} was not found."));
        }

        var team = _mapper.Map<Team>(dto);
        team.Id = id;
        team.Description = existingTeam.Description;

        await _repository.UpdateAsync(team);

        var updatedTeam = await _repository.GetAsync(id);
        var result = _mapper.Map<TeamDto>(updatedTeam);

        return Ok(ReturnResult<TeamDto>.Ok(
            result!,
            "Team updated successfully."));
    }

    [HttpDelete("{id:int}")]
    public async Task<ActionResult<ReturnResult<object>>> Delete(int id)
    {
        var existingTeam = await _repository.GetAsync(id);

        if (existingTeam == null)
        {
            return NotFound(ReturnResult<object>.Fail(
                $"Team with id {id} was not found."));
        }

        await _repository.DeleteAsync(id);

        return Ok(ReturnResult<object>.Ok(
            new { id },
            "Team deleted successfully."));
    }

    [HttpGet("city/{city}")]
    public async Task<ActionResult<ReturnResult<IEnumerable<TeamDto>>>> GetByCity(
        string city)
    {
        if (string.IsNullOrWhiteSpace(city))
        {
            return BadRequest(ReturnResult<IEnumerable<TeamDto>>.Fail(
                "City is required."));
        }

        var teams = await _repository.GetByCityAsync(city);
        var result = _mapper.Map<IEnumerable<TeamDto>>(teams);

        return Ok(ReturnResult<IEnumerable<TeamDto>>.Ok(
            result,
            $"Teams from city '{city}' retrieved successfully."));
    }
}
