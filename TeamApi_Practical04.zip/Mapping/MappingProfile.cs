using AutoMapper;
using TeamApi_Practical04.DTOs;
using TeamApi_Practical04.Models;

namespace TeamApi_Practical04.Mapping;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        CreateMap<Team, TeamDto>().ReverseMap();
    }
}
