using System.ComponentModel.DataAnnotations;

namespace TeamApi_Practical04.Models;

public class Team
{
    public int Id { get; set; }

    [Required]
    [MaxLength(150)]
    public string Name { get; set; } = string.Empty;

    [Required]
    [MaxLength(100)]
    public string City { get; set; } = string.Empty;

    [MaxLength(1000)]
    public string? Description { get; set; }
}
